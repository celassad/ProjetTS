/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2018 by Laurent Réveillère
 ******************************************************************************/
#ifndef MAP_H_
#define MAP_H_
#include <stdio.h>


enum cell_type {
	CELL_EMPTY=0x00,   		//  0000 0000
	CELL_SCENERY=0x10, 		//  0001 0000
	CELL_BOX=0x20,   		//  0010 0000
	CELL_DOOR=0x30,      	//  0011 0000
	CELL_KEY=0x40,       	//  0100 0000
	CELL_BONUS=0x50, 		// 	0101 0000
	CELL_MONSTER=0x60, 		// 	0110 0000
	CELL_BOMB=0x70, 	   		// 	0111 0000
	EXPLOSION=0x80               // 1000 0000

};

enum monster_type {
  MONSTER_UP = 0x60,
  MONSTER_DOWN = 0x61,
  MONSTER_LEFT = 0x62,
  MONSTER_RIGHT = 0x63
};



enum bomb_type {
  BOMB_1 =  0x71,              // 0111 0001
  BOMB_2 =  0x72,              // 0111 0010
  BOMB_3 =  0x73,              // 0111 0011
  BOMB_4 =  0x74             // 0111 0100
};
  enum bonus_type {
	BONUS_BOMB_RANGE_DEC=1,
	BONUS_BOMB_RANGE_INC,
	BONUS_BOMB_NB_DEC,
	BONUS_BOMB_NB_INC,
	BONUS_MONSTER,
	BONUS_LIFE
};

enum scenery_type {
	SCENERY_STONE,     // 0000
	SCENERY_TREE,      // 0010
	SCENERY_PRINCESS   // 0010
};
enum door_state {
	DOOR_CLOSED,	// 0000
	DOOR_OPEN	// 0001
};

enum door_level {
  DOOR_0 = 0x00,  // 0000 0000
  DOOR_1 = 0x02,	// 0000 0010
  DOOR_2 = 0x04,	// 0000 0100
  DOOR_3 = 0x06,	// 0000 0110
  DOOR_4 = 0x08,	// 0000 1000
  DOOR_5 = 0x10,	// 0000 1010
  DOOR_6 = 0x12,	// 0000 1100
  DOOR_7 = 0x14  	// 0000 1110
};
enum compose_type {
	CELL_TREE     = CELL_SCENERY | SCENERY_TREE,
	CELL_STONE    = CELL_SCENERY | SCENERY_STONE,
	CELL_PRINCESS = CELL_SCENERY | SCENERY_PRINCESS,

    CELL_BOX_RANGEINC = CELL_BOX | BONUS_BOMB_RANGE_DEC,
    CELL_BOX_RANGEDEC = CELL_BOX | BONUS_BOMB_RANGE_INC,
	CELL_BOX_BOMBINC  = CELL_BOX | BONUS_BOMB_NB_DEC,
    CELL_BOX_BOMBDEC  = CELL_BOX | BONUS_BOMB_NB_INC,
    CELL_BOX_LIFE     = CELL_BOX | BONUS_MONSTER,
    CELL_BOX_MONSTER  = CELL_BOX | BONUS_LIFE
};
enum door_full_type {
  DOOR_0_OPEN = 0x31,  // 0011 0001 = 49
  DOOR_1_OPEN = 0x33,	// 0011 0011 = 51
  DOOR_2_OPEN = 0x35,	// 0011 0101 = 53
  DOOR_3_OPEN = 0x37,	// 0011 0111 = 55
  DOOR_4_OPEN = 0x39,	// 0011 1001 = 57
  DOOR_5_OPEN = 0x3b,	// 0011 1011 = 59
  DOOR_6_OPEN = 0x3d,	// 0011 1101 = 61
  DOOR_7_OPEN = 0x3f,  	// 0011 1111 = 63
  DOOR_0_CLOSED = 0x30, // 0011 0000 = 48
  DOOR_1_CLOSED = 0x32,	// 0011 0010 = 50
  DOOR_2_CLOSED = 0x34,	// 0011 0100 = 52
  DOOR_3_CLOSED = 0x36,	// 0011 0110 = 54
  DOOR_4_CLOSED = 0x38,	// 0011 1000 = 56
  DOOR_5_CLOSED = 0x3a,	// 0011 1010 = 58
  DOOR_6_CLOSED = 0x3c,	// 0011 1100 = 60
  DOOR_7_CLOSED = 0x3e  // 0011 1110 = 62


};
struct map;

// Create a new empty map
struct map* map_new(int width, int height);
void map_free(struct map* map);


// Return the height and width of a map
int map_get_width(struct map* map);
int map_get_height(struct map* map);

// Return the type of a cell
enum cell_type map_get_cell_type(struct map* map, int x, int y);
unsigned char map_get_full_cell_type(struct map* map, int x, int y);

//get door state: open or closed
enum door_state map_get_door_state(struct map* map, int x, int y);

void map_change_door_state(struct map* map, int x, int y);

// Set the type of a cell
void  map_set_cell_type(struct map* map, int x, int y, enum cell_type type);
void map_set_cell(struct map* map, int x, int y, unsigned char type);
// Test if (x,y) is within the map
int map_is_inside(struct map* map, int x, int y);

// Return a default static map
struct map* map_get_static();

// Display the map on the screen
void map_display(struct map* map);
struct map* map_load_file(char* file);

//returns the next level, T is the door type
int map_next_level(char T);

//returns x and y if cell = cell(x,y)
int map_get_x(struct map* map,int cell);
int map_get_y(struct map* map,int cell);
int map_search_door(struct map* map, int level);


////////BOMBS//////
void display_bomb(struct map* map, int x, int y, unsigned char type);

////save///
void map_save(struct map* map,FILE* file);

#endif /* MAP_H_ */
