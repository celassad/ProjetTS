/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2018 by Laurent Réveillère
 ******************************************************************************/
#ifndef BOMB_H_
#define BOMB_H_
struct bomb;
#include <map.h>
#include <game.h>


struct bomb* bomb_new(int x, int y,struct game* game);
void bomb_set_age(struct bomb* bomb, int t);
int bomb_get_age(struct bomb* bomb);
void bomb_set_range(struct bomb* bomb, int r);
void bomb_update_age(struct game*, struct bomb* bomb);
int bomb_get_x(struct bomb* bomb);
int bomb_get_y(struct bomb* bomb);
int bomb_get_range(struct bomb* bomb);
void bomb_set_exploded(struct bomb* bomb, int e);
int bomb_get_exploded(struct bomb* bomb);

void game_explode_bomb(struct game* game, struct bomb* bomb);
void game_explode_cell(struct game* game,struct map* map, int x, int y);
void game_end_explosion(struct game* game, struct bomb* bomb);
void game_put_bomb(struct game* game);
struct map* bomb_get_map(struct bomb* bomb);
#endif /* BOMB_H_ */
