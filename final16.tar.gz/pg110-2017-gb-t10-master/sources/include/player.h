/*******************************************************************************
 * This file is part of Bombeirb.
 * Copyright (C) 2018 by Laurent Réveillère
 ******************************************************************************/
#ifndef PLAYER_H_
#define PLAYER_H_

#include <map.h>
#include <constant.h>
struct player;
#include <game.h>

// Creates a new player with a given number of available bombs
struct player* player_init(int bomb_number,int);
void   player_free(struct player* player);

// Set the position of the player
void player_set_position(struct player *player, int x, int y);

// Returns the current position of the player
int player_get_x(struct player* player);
int player_get_y(struct player* player);

// Set the direction of the next move of the player
void player_set_current_way(struct player * player, enum direction direction);

// Set, Increase, Decrease the number of bomb that player can put
int  player_get_nb_bomb(struct player * player);
void player_inc_nb_bomb(struct player * player);
void player_dec_nb_bomb(struct player * player);
void player_set_nb_bomb(struct player* player, int n);
void player_set_nbkeys(struct player* player,int b);
void player_set_lives(struct player* player, int c); 

int player_get_fnb_bomb(struct player* player);
void player_set_fnb_bomb(struct player* player, int n);
void player_inc_fnb_bomb(struct player* player);
void player_dec_fnb_bomb(struct player* player);


//bomb range
int player_get_bomb_range(struct player* player);
void player_inc_bomb_range(struct player* player);
void player_dec_bomb_range(struct player* player);
void player_set_bomb_range(struct player* player,int range);

//player lives
void player_dec_lives(struct player* player);
void player_inc_lives(struct player* player);
int player_get_lives(struct player* player);


// get, increase, decrease the number of keys
void player_inc_nb_key(struct player* player) ;
  void player_dec_nb_key(struct player* player) ;
  int player_get_nb_key(struct player* player);
// Move the player according to the current direction
int player_move(struct player* player, struct map* map);


// Display the player on the screen
void player_display(struct player* player);

//timer RET
void player_set_RET(struct player* player,int ret);
int player_get_RET(struct player* player);
int player_get_timer(struct player* player);
void player_set_timer(struct player* player,int t);
void player_set_immunity(struct player* player,int i);
int player_get_immunity(struct player* player);

#endif /* PLAYER_H_ */
