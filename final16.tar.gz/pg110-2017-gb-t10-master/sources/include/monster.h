#ifndef MONSTER_H_
#define MONSTER_H_
struct monster;
#include <map.h>
#include <player.h>
#include <game.h>
struct monster* new_monster(struct map* map,struct player*);
void monster_display(struct monster* monster);

int monster_get_x(struct monster* monster);
int monster_get_y(struct monster* monster);
struct map* monster_get_map(struct monster* monster);

int monster_get_birth(struct monster* monster);
void monster_set_age(struct monster* monster, int age);
int monster_get_age(struct monster* monster);
void monster_set_birth(struct monster* monster, int birth);

int monster_move(struct game*,struct monster* monster, struct map* map,struct player*);




#endif /* MONSTER_H_ */
