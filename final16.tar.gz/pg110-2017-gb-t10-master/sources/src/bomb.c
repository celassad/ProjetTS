#include <SDL/SDL_image.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <constant.h>
#include <misc.h>
#include <window.h>
#include <bomb.h>

#define CELL(i,j) ( (i) + (j) * map_get_width(game_get_current_map(game)) )
struct bomb {
  int birth;
  int age;
  int range;
  int x;
  int y;
  int exploded;
  struct map* map;
};

struct bomb* bomb_new(int x, int y, struct game* game) {
  struct bomb* B = malloc(sizeof(struct bomb));
  B -> birth = SDL_GetTicks();
  B -> age = 0;
  B -> range = 1;
  B -> x = x;
  B -> y = y;
  B -> exploded = 0;
  B -> map = game_get_current_map(game);
  return B;
}

struct map* bomb_get_map(struct bomb* bomb) {
  assert(bomb);
  return bomb -> map;

}

void bomb_set_range(struct bomb* bomb, int r) {
  assert(bomb);
  bomb -> range = r;
}

int bomb_get_range(struct bomb* bomb) {
  assert(bomb);
  return bomb -> range;
}

void bomb_set_age(struct bomb* bomb, int t) {
  assert(bomb);
  bomb -> age = t;
}

int bomb_get_x(struct bomb* bomb) {
  assert(bomb);
  return bomb->x;
}

int bomb_get_y(struct bomb* bomb) {
  assert(bomb);
  return bomb->y;
}


int bomb_get_age(struct bomb* bomb) {
  assert(bomb);
  return bomb -> age;
}

void bomb_update_age(struct game* game, struct bomb* bomb) {
  assert(bomb);
  int total_pausetime = game_get_total_pausetime(game);
  bomb -> age = SDL_GetTicks() - total_pausetime - bomb->birth;
}

void game_put_bomb(struct game* game) {
  struct player* player = game_get_player(game);
  int x = player_get_x(player);
  int y = player_get_y(player);
  struct map* map = game_get_current_map(game);
  int H = map_get_height(map);
  int W = map_get_width(map);
  struct bomb* bomb = bomb_new(x,y,game);
  bomb_set_range(bomb,player_get_bomb_range(player));
  for (int i=0;i<H*W;i++)
    if (game_get_bomb(game,i)==NULL){
      game_set_bomb(game,bomb,i);
      break;
    }
}


void game_explode_bomb(struct game* game, struct bomb* bomb) {
  struct map* map = bomb_get_map(bomb);
  int x = bomb_get_x(bomb);
  int y = bomb_get_y(bomb);
  int range = bomb_get_range(bomb);
  if(bomb_get_exploded(bomb))
      return ;

   if(map_is_inside(map,x,y))
     game_explode_cell(game,map,x,y);

   //============================== x+i ===============================
   unsigned char cell_type ;
   for(int i=1; i<=range; i++){
     if(!map_is_inside(map,x+i,y))
       break;
     cell_type = map_get_cell_type(map,x+i,y);
     if(cell_type == CELL_BOX){
       game_explode_cell(game,map,x+i,y);
       break;
     }else if(cell_type == CELL_SCENERY) {
       break;
     }else{
       game_explode_cell(game,map,x+i,y);
     }
   }


   //============================== x-i ===============================

   for(int i=1; i<=range; i++){
     if (!map_is_inside(map,x-i,y))
       break;
     cell_type = map_get_cell_type(map,x-i,y);
     if(cell_type == CELL_BOX){
       game_explode_cell(game,map,x-i,y);
       break;
     }else if(cell_type == CELL_SCENERY) {
       break;
     }else{
       game_explode_cell(game,map,x-i,y);
     }
   }


   //============================== y+i ===============================

   for(int i=1; i<=range; i++){
     if(!map_is_inside(map,x,y+i))
       break;
     cell_type = map_get_cell_type(map,x,y+i);
     if(cell_type == CELL_BOX){
       game_explode_cell(game,map,x,y+i);
       break;
     }else if(cell_type == CELL_SCENERY) {
       break;
     }else{
       game_explode_cell(game,map,x,y+i);
     }
   }

   //============================== y-i ===============================

   for(int i=1; i<=range; i++){
     if (!map_is_inside(map,x,y-i))
       break;
     cell_type = map_get_cell_type(map,x,y-i);
     if(cell_type == CELL_BOX){
       game_explode_cell(game,map,x,y-i);
       break;
		  }else if(cell_type == CELL_SCENERY) {
       break;
     }else{
       game_explode_cell(game,map,x,y-i);
     }
		}

 bomb_set_exploded(bomb,1);

}

void bomb_set_exploded(struct bomb* bomb, int e) {
  assert(bomb);
  bomb -> exploded = e;
}

int bomb_get_exploded(struct bomb* bomb) {
  assert(bomb);
  return bomb->exploded;
}


  void game_end_explosion(struct game* game, struct bomb* bomb) {
    struct map* map = bomb_get_map(bomb);
    int x = bomb_get_x(bomb);
    int y = bomb_get_y(bomb);
    int range = bomb_get_range(bomb);

    for (int i=-range; i<=range ;i++) {

      if(map_is_inside(map,x+i,y)) {
	unsigned char a = map_get_full_cell_type(map,x+i,y);

	if(map_get_cell_type(map,x+i,y) == EXPLOSION && ((a & 0x0f) == 0))
	  map_set_cell(map,x+i,y,CELL_EMPTY);
	else if (map_get_cell_type(map,x+i,y) == EXPLOSION && ((a & 0x0f) != 0))
	  map_set_cell_type(map,x+i,y,CELL_BONUS | (a & 0x0f));
      }

      if(i!=0 && map_is_inside(map,x,y+i)) {
	unsigned char b = map_get_full_cell_type(map,x,y+i);
	if(map_get_cell_type(map,x,y+i) == EXPLOSION && ((b & 0x0f) == 0))
	map_set_cell(map,x,y+i,CELL_EMPTY);
	else if (map_get_cell_type(map,x,y+i) == EXPLOSION && ((b & 0x0f) != 0))
	  map_set_cell_type(map,x,y+i,CELL_BONUS | (b & 0x0f));
      }
    }
    game_set_bomb(game,NULL,CELL(x,y));
  }


void game_explode_cell(struct game* game,struct map* map, int x, int y) {

  if (map_is_inside(map,x,y)) {
    unsigned char a = map_get_full_cell_type(map,x,y);
    switch(map_get_cell_type(map,x,y)) {
    case CELL_SCENERY:
      break;
    case CELL_BOX:
      {
	unsigned char b = ( a & 0x0f ) | 0x80 ;   //full type of explosion (includes bonus types)
	map_set_cell(map,x,y,b);
      }
      break;

    case CELL_KEY:
      break;

    case CELL_DOOR:
      break;
    case EXPLOSION:
      map_set_cell(map,x,y,a);
      break;
    default:
      map_set_cell(map,x,y,EXPLOSION);
      break;
    }
  }
}
